---
name: drive-device-fixture
description: Drive the synthetic device fixture through its sim
  transport; registry-admission fixture content only.
---

# Driving the device fixture

Connect via the sim transport, apply the fixture profile, and read
the simulated measurements. Synthetic fixture content proving the
skill payload-file role end to end.
